package com.example.not_tachi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
